# Projeto IA Rachadura 2 > Versao Modelo 2
https://universe.roboflow.com/projeto-ia-rachadura/projeto-ia-rachadura-2

Provided by a Roboflow user
License: CC BY 4.0

